var mongoose = require('mongoose');
var Friend = mongoose.model('Friend');
module.exports = {
  index: function(req,res){
    Friend.find({}, function(err, data){
      if(err){
        res.status(400).send("Error");
      }
      res.json(data);
    });
  },
  create: function(req,res){
    var friend = new Friend(req.body);
    friend.save(function(err,data){
      if(err){
        res.status(400).send("Friend not save");
      }
      res.sendStatus(200);
    });
  },
  update: function(req,res){
    Friend.update({_id:req.params.id}, req.body, function(err,data){
      if(err){
        res.status(400).send("Friend not updated");
      }
      res.sendStatus(200);
    })
  },
  delete: function(req,res){
    Friend.findOne({_id:req.params.id}, function(err, data){
      if(data == null){
        res.status(400).send("Friend is not there");
      }
      data.remove();
      res.status(200).send("Friend was removed");
    });
  },
  show: function(req,res){
    Friend.findOne({_id:req.params.id}, function(err, data){
      if(data == null){
        res.status(400).send("Friend is not there");
      }
      res.json(data);
    });
  }
}
